export default function () {
    const Fly = require("flyio/src/node")
    return new Fly
}
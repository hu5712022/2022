export const neteaseMusic = {
    id: 27808044,
    artistId: 11127,
    playlistId: 483222600,
    albumId: 29597,
    translateLyricId: 3026472
}
export const qqMusic = {
    id: 5106429,
    artistId: 2,
    playlistId: 2890182907,
    albumId: 1458791,
    translateLyricId: 432263
}